# Virtual DJ Mobile — Expanded prototype (V2)

This is an expanded Android source project. **It is not a prebuilt APK** and has not been compiled or device-tested in this environment.

## Prototype features
- Two independent Android `MediaPlayer` decks
- Import audio files through the Android document picker
- Play/pause, stop, set cue, return to cue, stutter/retrigger
- Track-position slider and a decorative generated waveform visualization
- Manual BPM controls for both decks and master tempo
- Basic tempo matching toggle (sets each deck playback speed relative to manually entered BPM)
- Pitch/tempo slider and Key Lock toggle using Android `PlaybackParams` where supported
- Low/Mid/High EQ sliders backed by Android `Equalizer` audio effect where supported
- Equal-power crossfader
- Dark mobile-friendly interface

## Limitations
- BPM is manual; no automatic beat detection.
- The waveform bars are decorative, not extracted from audio samples.
- Playback speed and pitch behavior vary by device and codec. Key Lock is an approximation using Android playback parameters, not high-quality time-stretching.
- EQ depends on Android audio effect support and device implementation.
- No true scratching/jog-wheel audio manipulation, professional low-latency mixing engine, independent headphone cue bus, or background mixing service.
- Audio behavior, UI, and compilation still need to be tested on a real Android device.

## Build the APK without installing an Android IDE on your phone
This project includes a GitHub Actions workflow to build the APK in the cloud.

1. Download and extract the project ZIP.
2. Create/sign in to a GitHub account and create a **new repository**.
3. Upload the contents of the `VirtualDJAndroid` folder to the repository (including the `.github` folder).
4. Open the repository's **Actions** tab. If prompted, enable Actions.
5. Select **Build Virtual DJ APK** and choose **Run workflow** (or push to the `main` branch).
6. Wait for the workflow to finish. Open the successful run and download the **VirtualDJ-debug-apk** artifact.
7. Extract the artifact ZIP to get `app-debug.apk`, then install it on your Android phone. You may need to allow installation from that file manager/browser.

## Local build
Open the project in Android Studio and run `gradle assembleDebug` (requires Android SDK 35 and Gradle 8.9). The APK output is `app/build/outputs/apk/debug/app-debug.apk`.
