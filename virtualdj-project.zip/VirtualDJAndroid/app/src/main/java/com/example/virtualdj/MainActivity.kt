package com.example.virtualdj

import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF0A0E12)
private val SurfaceDJ = Color(0xFF171F27)
private val Cyan = Color(0xFF35D6F3)
private val Orange = Color(0xFFFFB34D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DJScreen() }
    }
}


class DJDeck {
    var mp: MediaPlayer? = null
    var eq: Equalizer? = null
    var name by mutableStateOf("No track loaded")
    var ready by mutableStateOf(false)
    var playing by mutableStateOf(false)
    var duration by mutableIntStateOf(0)
    var position by mutableIntStateOf(0)
    var cue by mutableIntStateOf(0)
    var bpm by mutableFloatStateOf(120f)
    var speed by mutableFloatStateOf(1f)
    var keyLock by mutableStateOf(false)
    var low by mutableFloatStateOf(0f) // dB
    var mid by mutableFloatStateOf(0f)
    var high by mutableFloatStateOf(0f)
    private var baseVolume = 1f

    fun load(context: android.content.Context, uri: Uri, label: String) {
        release()
        name = label
        val p = MediaPlayer()
        mp = p
        try {
            p.setDataSource(context, uri)
            p.setOnPreparedListener { prepared ->
                duration = prepared.duration.coerceAtLeast(0)
                position = 0
                ready = true
                try {
                    eq = Equalizer(0, prepared.audioSessionId).also { it.enabled = true }
                    applyEQ()
                } catch (_: Exception) { eq = null }
            }
            p.setOnCompletionListener { playing = false; position = duration }
            p.setOnErrorListener { _, _, _ -> playing = false; ready = false; true }
            p.prepareAsync()
        } catch (_: Exception) {
            name = "Unable to open audio file"
            ready = false
        }
    }
    fun playPause() {
        val p = mp ?: return
        if (!ready) return
        if (p.isPlaying) { p.pause(); playing = false } else { p.start(); playing = true }
    }
    fun stop() { mp?.let { if (it.isPlaying) it.pause(); it.seekTo(0) }; playing = false; position = 0 }
    fun setCue() { cue = mp?.currentPosition ?: 0 }
    fun jumpCue(playAfter: Boolean = false) {
        mp?.let { p -> p.seekTo(cue); position = cue; if (playAfter && !p.isPlaying) { p.start(); playing = true } }
    }
    fun stutter() { jumpCue(true) }
    fun seek(ms: Int) { mp?.seekTo(ms.coerceIn(0, duration)); position = ms.coerceIn(0, duration) }
    fun tick() { mp?.let { if (it.isPlaying) position = it.currentPosition } }
    fun setVolume(v: Float) { baseVolume = v.coerceIn(0f, 1f); mp?.setVolume(baseVolume, baseVolume) }
    fun setTempo(multiplier: Float) {
        speed = multiplier.coerceIn(0.75f, 1.25f)
        try { mp?.let { player -> val params = player.playbackParams; params.setSpeed(speed); params.setPitch(if (keyLock) 1f else speed); player.playbackParams = params } } catch (_: Exception) { }
    }
    fun toggleKeyLock(on: Boolean) { keyLock = on; setTempo(speed) }
    fun applyEQ() {
        val e = eq ?: return
        try {
            val range = e.bandLevelRange
            val max = range[1].toFloat(); val min = range[0].toFloat()
            for (band in 0 until e.numberOfBands) {
                val center = e.getCenterFreq(band.toShort()) / 1000f
                val gain = when { center < 250f -> low; center < 4000f -> mid; else -> high }
                e.setBandLevel(band.toShort(), (gain * 100).toInt().coerceIn(min.toInt(), max.toInt()).toShort())
            }
        } catch (_: Exception) { }
    }
    fun release() {
        try { eq?.release() } catch (_: Exception) { }
        eq = null
        try { mp?.release() } catch (_: Exception) { }
        mp = null; ready = false; playing = false; duration = 0; position = 0; cue = 0
    }
}


@Composable
fun DJScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val a = remember { DJDeck() }; val b = remember { DJDeck() }
    var cross by remember { mutableFloatStateOf(0.5f) }
    var sync by remember { mutableStateOf(false) }
    var masterBpm by remember { mutableFloatStateOf(120f) }
    val pickA = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { a.load(ctx, it, it.lastPathSegment?.substringAfterLast('/') ?: "Deck A") } }
    val pickB = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { b.load(ctx, it, it.lastPathSegment?.substringAfterLast('/') ?: "Deck B") } }
    fun fade() { a.setVolume(cos(cross * Math.PI / 2).toFloat().coerceAtLeast(0f)); b.setVolume(sin(cross * Math.PI / 2).toFloat().coerceAtLeast(0f)) }
    LaunchedEffect(Unit) { while (true) { a.tick(); b.tick(); delay(250) } }
    DisposableEffect(Unit) { onDispose { a.release(); b.release() } }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = SurfaceDJ)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(10.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("VIRTUAL DJ", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineSmall); Text("MOBILE MIXER", color = Cyan, style = MaterialTheme.typography.labelSmall) }
                Text("2-DECK", color = Orange, fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DeckPanel("DECK A", a, Cyan, { pickA.launch(arrayOf("audio/*")) }, { a.playPause() }, { a.setCue() }, { a.jumpCue() }, { a.stutter() }, { a.stop() }, Modifier.weight(1f))
                DeckPanel("DECK B", b, Orange, { pickB.launch(arrayOf("audio/*")) }, { b.playPause() }, { b.setCue() }, { b.jumpCue() }, { b.stutter() }, { b.stop() }, Modifier.weight(1f))
            }
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDJ)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MASTER / SYNC", color = Color.White, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("Master BPM ${masterBpm.toInt()}", color = Cyan); Spacer(Modifier.weight(1f)); Switch(sync, { sync = it; if (it) { a.setTempo(masterBpm / a.bpm); b.setTempo(masterBpm / b.bpm) } }) }
                    Slider(masterBpm, { masterBpm = it; if (sync) { a.setTempo(masterBpm / a.bpm); b.setTempo(masterBpm / b.bpm) } }, valueRange = 80f..180f)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("80 BPM", color = Color.Gray); Text("180 BPM", color = Color.Gray) }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDJ)) {
                Column(Modifier.padding(12.dp)) {
                    Text("CROSSFADER", color = Color.White, fontWeight = FontWeight.Bold)
                    Slider(cross, { cross = it; fade() }, colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Cyan))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("A", color = Cyan); Text("CENTER", color = Color.Gray); Text("B", color = Orange) }
                }
            }
            Text("3-BAND EQ", color = Color.White, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { EQPanel("A", a, Cyan, Modifier.weight(1f)); EQPanel("B", b, Orange, Modifier.weight(1f)) }
            Text("Note: BPM is manually adjustable. Sync matches the decks to the master tempo. Audio processing depends on Android device support.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}


@Composable
private fun DeckPanel(title: String, d: DJDeck, color: Color, load: () -> Unit, play: () -> Unit, cue: () -> Unit, returnCue: () -> Unit, stutter: () -> Unit, stop: () -> Unit, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = SurfaceDJ), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = color, fontWeight = FontWeight.Black)
            Text(d.name, color = Color.White, minLines = 2, maxLines = 2, style = MaterialTheme.typography.bodySmall)
            Text(if (d.playing) "● PLAYING" else "■ READY / PAUSED", color = color, style = MaterialTheme.typography.labelSmall)
            WaveBars(d.position, d.duration, color, Modifier.fillMaxWidth().height(46.dp))
            Slider(value = if (d.duration > 0) d.position.toFloat().coerceIn(0f, d.duration.toFloat()) else 0f, onValueChange = { d.seek(it.toInt()) }, valueRange = 0f..d.duration.coerceAtLeast(1).toFloat(), enabled = d.ready)
            Text("${time(d.position)} / ${time(d.duration)}", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
            Button(load, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF303B48))) { Text("LOAD TRACK") }
            Button(play, Modifier.fillMaxWidth(), enabled = d.ready, colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.Black)) { Text(if (d.playing) "PAUSE" else "PLAY", fontWeight = FontWeight.Bold) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedButton(cue, Modifier.weight(1f), enabled = d.ready, contentPadding = PaddingValues(3.dp)) { Text("SET CUE", style = MaterialTheme.typography.labelSmall) }
                OutlinedButton(returnCue, Modifier.weight(1f), enabled = d.ready, contentPadding = PaddingValues(3.dp)) { Text("CUE", style = MaterialTheme.typography.labelSmall) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedButton(stutter, Modifier.weight(1f), enabled = d.ready, contentPadding = PaddingValues(3.dp)) { Text("STUTTER", style = MaterialTheme.typography.labelSmall) }
                OutlinedButton(stop, Modifier.weight(1f), enabled = d.ready, contentPadding = PaddingValues(3.dp)) { Text("STOP", style = MaterialTheme.typography.labelSmall) }
            }
            Text("BPM ${d.bpm.toInt()}", color = color, style = MaterialTheme.typography.labelSmall)
            Slider(d.bpm, { d.bpm = it }, valueRange = 80f..180f)
            Text("PITCH / TEMPO ${(d.speed * 100).toInt()}%", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
            Slider(d.speed, { d.setTempo(it) }, valueRange = 0.75f..1.25f)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("KEY LOCK", color = Color.LightGray, style = MaterialTheme.typography.labelSmall); Spacer(Modifier.weight(1f)); Switch(d.keyLock, { d.toggleKeyLock(it) }) }
        }
    }
}


@Composable
private fun EQPanel(label: String, d: DJDeck, accent: Color, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = SurfaceDJ)) {
        Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("DECK $label", color = accent, fontWeight = FontWeight.Bold)
            EQKnob("LOW", d.low, accent, { d.low = it; d.applyEQ() })
            EQKnob("MID", d.mid, accent, { d.mid = it; d.applyEQ() })
            EQKnob("HIGH", d.high, accent, { d.high = it; d.applyEQ() })
        }
    }
}
@Composable
private fun EQKnob(name: String, value: Float, color: Color, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(name, color = Color.LightGray, style = MaterialTheme.typography.labelSmall); Text("${value.toInt()} dB", color = color, style = MaterialTheme.typography.labelSmall) }
        Slider(value, onChange, valueRange = -12f..12f, colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color))
    }
}
@Composable
private fun WaveBars(position: Int, duration: Int, color: Color, modifier: Modifier) {
    val seed = (duration / 1000).coerceAtLeast(1)
    Canvas(modifier.background(Color(0xFF0C1116), RoundedCornerShape(8.dp))) {
        val count = 48; val gap = 2f; val width = (size.width - gap * (count - 1)) / count
        for (i in 0 until count) {
            val amp = ((i * 37 + seed * 13) % 100) / 100f
            val h = size.height * (0.15f + amp * 0.78f)
            val x = i * (width + gap)
            val progress = if (duration > 0) position.toFloat() / duration else 0f
            val barColor = if (i / count.toFloat() < progress) color else color.copy(alpha = 0.25f)
            drawRoundRect(barColor, androidx.compose.ui.geometry.Offset(x, (size.height - h) / 2), androidx.compose.ui.geometry.Size(width, h), androidx.compose.ui.geometry.CornerRadius(2f, 2f))
        }
    }
}
private fun time(ms: Int): String { val sec = (ms / 1000).coerceAtLeast(0); return "%02d:%02d".format(sec / 60, sec % 60) }
